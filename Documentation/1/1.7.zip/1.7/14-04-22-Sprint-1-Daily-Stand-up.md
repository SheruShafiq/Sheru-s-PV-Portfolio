Daily standup was nogal klein vandaag, Nick en Pelle waren ziek. Julian was in de avond al begonnen met het opzetten van head en hand tracking en die gaat dat afmaken. Sheru gaat vandaag beginnen met een primitive version van het appartement te maken.

Goals of the day:
- Julian: Head and hand tracking af met hand models
- Sheru: Primitive appartement neerzetten
- Nick: Ziek
- Pelle: Presumed ziek (geen bericht voor de standup van gehad)