Iedereen is aanwezig op tijd, we hebben de Donderdag ervoor meeting gehad met Hans en alles besproken wat we nog gaan doen.

### Goals of the day
- Julian: Documentatie en mails versturen
- Sheru: Begin aan game 4
- Nick: Opschonen van oude scenes