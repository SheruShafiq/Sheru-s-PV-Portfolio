Wat ging goed?
- Samenwerking
- Communicatie Onderling
- Hoeveel werk we gedaan hadden
- Een werkende Demo in week 1

Wat kon beter gaan?
- Nick en Pelle nog niet klaar met Unity Modules
- Sheru koppigheid
- Julian onvoorbereid voor de demo
- Alleen Julian en Sheru hebben aan het project gewerkt

Ideas?
- Langs gaan bij een model woning en fotos maken om te fotos te maken en inspiratie te krijgen

Praise
- Julian & Sheru 


Afspraken: 
- Nick en Pelle klaar met unity 21 april en iets bijdragen aan de codebase voor 26 april
