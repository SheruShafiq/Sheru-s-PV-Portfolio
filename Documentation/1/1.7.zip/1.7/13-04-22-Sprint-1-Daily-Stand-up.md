We hebben als team even de stand van zaken doorgenomen en tegen het probleem aangelopen dat 2/4 teamleden nog de Unity Create With Code moeten afmaken. Hierdoor hebben we hun deze sprint de tijd gegeven om dit af te maken.

Goals for the day:
- Julian: Project en workspace setup
- Sheru: Workspace setup
- Pelle: Create with code 3.2 af
- Nick: Create with code 1 af