Nick is ziek, we lopen misschien achter op de particle effects. Sheru gaat daarom hier naar kijken als hij wat tijd over heeft. Verder is er niet veel te melden, er is nog veel te doen en we hebben een goed gevulde backlog.

### Goals of the day!!!
- Julian: Scene Transitions & Begin aan de buitenwereld
- Sheru: Assistant animations voor opdracht 2 & begin aan particle effects voor opdracht 2