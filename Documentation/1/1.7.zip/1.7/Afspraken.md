### Team Afspraken

- Daily stand-up: 10:30
- Bij ziekmelding meld het aan teamgenoten voor 10:30
- Kost het meer tijd dan verwacht geef dit aan zodra je dit merkt
- Als je niks te doen hebt check de backlog en als er niks staat vraag het aan Julian

### Coding Stijl

- Branch naam format: {feature, bug, fe, etc}/{naam} example: feature/syntax-highlighter
- Variable namen: camelBack
- Functie namen: FooBar

### Verantwoording

- Product owner: Hans Stokking van TNO 
- Scrum master: Julian
- Klant contact: Julian

### Roterende rollen
- Git Master: Sheru
- Voorzitter: Julian
- Notaris: Pelle
- Dev Advocate: Nick