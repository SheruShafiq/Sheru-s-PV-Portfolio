We kregen in het weekend te horen dat Pelle het team verlaat. Nick is klaar met game development en is opgezet in de project omgeving en is bezig met werken vanaf vandaag. MVP staat al redelijk klaar we zijn nu bezig met het implementeren van wat nice to haves. Ook heeft Hans een documentje gestuurd met wensen en die gaat Julian vandaag doornemen.

### Goals
- Nick: Implement Water particles en sound effects
- Sheru: Splits de huidige scene op in meerdere scenes om performance te verbeteren
- Julian: Text 2 Speech implementatie en wat project management