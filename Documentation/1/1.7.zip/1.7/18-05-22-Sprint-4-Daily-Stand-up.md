Sheru was een beetje laat wegens OV,

### Goals
- Julian: PlasticSCM fout fixen 
- Sheru: Werken aan optimalisatie 
- Nick: Binnen omgeving mooier maken, conditionele binnen planten toevoegen.