Nick is ziek, in de ochtend meeting met de Stichting Wonen, Boudewijn, Kelly, Hans en Lulu gehad. Ze zijn nog even als niet nog meer enthousiast over het project en hadden het over een heel PR circus eromheen te bouwen en ons op Kwaku neer te zetten met een podium. We hebben ook besproken wat we gaan doen voor de komende sprint en wat er nog hoge prioriteiten hebben. 

Goals of the day:
- Julian: Flow chart maken voor Kelly van de hele game en het beginnen van de scene bouwen voor game 3
- Sheru: Begin van het scripten van game 3 en fps optimalisaties uitvoeren