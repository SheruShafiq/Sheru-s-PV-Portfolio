Sheru was wat laat aanwezig dus we hadden het iets uitgesteld, we hebben even besproken wat we ook alweer wilde doen voor de vakantie en dit met z'n alle doorgenomen. Doel van de sprint is om de virtuele assistent te maken voor de game. 

### Goals
- Julian: Documentation work en assets zoeken
- Sheru: Assistent script voorbereiden 
- Nick: Water vfx & sfx afmaken en implementeren in main