Introductie – ontmoet je nieuw team.
Opdrachtgever – wat is de achtergrond?
een stichting die bewustzaamheid over duurzaamheid wekt bij bewoners
Project – waarom doen we dit?
Bewustzaamheid ontwikkelen binnen bewoners in zuid oost 
voor  informatie coaches die mensen hiermee kunnen opleiden in duurzaamheid
Doel - wanneer is dit project geslaagd? Wat staat er dan? Wat is 'succes'? Wat is jullie 'DoD'?
werkend product op de quest 

Core features - wat zijn de belangrijkste features van het product?

Must Haves:
virtual assistant die je vertelt over je keuzes en uitleg geeft
buiten lucht verandert op basis van correcte keuzes
Wallet die bijhoud hoeveel geld je bespaart op door de keuzes
foute keuze krijgt uitleg en de correcte keuze is nog steeds mogelijk
optie om dingen te kopen.
Tijds limiet van de game. 5-10m
tweetalig engels/nl

Could Haves:
verhaal op basis van een keuze die aanspreekt op achtergrond.

Should Haves:
hand tracking 

Won't Haves:

Aannames - zijn er aannames gemaakt? Dan controleer je die nu.

Is bedoeld voor mensen zonder VR ervaring 
Moet native werken op de Oculus headset?

Aanpak – hoe gaan we dit mogelijk maken? Hoe werken we samen?
sprint elke week op dinsdag, fysiek contact 

Planning - moeten er alvast meetings gepland worden?

	Dinsdag 19 april eerste sprint meeting

Q&A – zijn er nog openstaande punten?
doelgroepen:
alleenstaande moeders
studenten
oudere

Hans Stokking van TNO - Proxy product owner
hans.stokking@tno.nl	
0651608646

Indra ROC:
2084377@talnet.nl
indralieveld@gmail.com
