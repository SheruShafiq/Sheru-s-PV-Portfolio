We hebben eerst een retro gehouden over sprint 3 en afspraken gemaakt. Niemand gaat meer werken in main, en er moet wat opschoon werk gedaan worden. Ook moeten we bedenken hoe we meer uit de scrum methodiek kunnen halen want op dit moment is het vrij simpel gedaan, ook omdat we maar met 3 man zijn natuurlijk. Voor nu gaan we allemaal aan het werk om voor de volgende MvP alles te bouwen.

### Goals of the day
- Julian: Beginnen aan de Bijlmer omgeving bouwen & Oude branches opruimen
- Sheru: Bank opdracht afmaken
- Nick: Assests zoeken & implementeren voor de binnen omgeving