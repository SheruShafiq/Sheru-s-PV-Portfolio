Nick is ziek, 

### Goals of the day
- Julian: Animations for earlier levels
- Sheru: Completing level 4
- Nick: Dead