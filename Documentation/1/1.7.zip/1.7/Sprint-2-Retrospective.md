Wat ging goed?
- Samenwerking
- Communicatie Naar de klant
- MvP stond er zoals besproken
- Nick klaar met KD: Game Dev
- Goed voorbereid voor de sprint meeting

Wat kon beter gaan?
- Nick heeft niet iets kunnen bijdragen
- Performance kon iets beter

Ideas?
- De buiten wereld veranderen en zelf maken zodat het meer op de Bijlmer lijkt

Praise
- Sheru

Afspraken: 
- Geniet van de vakantie