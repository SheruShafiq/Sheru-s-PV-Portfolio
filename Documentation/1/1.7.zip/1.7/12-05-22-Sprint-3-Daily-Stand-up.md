Vandaag er nog even vol tegen aan. We hebben nog veel te en de 11de hebben we alleen maar aan burgerschap gezeten, vandaag ook nog deels. Iedereen was er tenminste vandaag dus dat is fijn.

### Goals of the day
- Julian: Living room scene bouwen
- Sheru: Assistant wat animaties geven
- Nick: Kraanwater afmaken