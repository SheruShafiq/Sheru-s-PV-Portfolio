# Vragen
### General feedback
- Vaste camera hoogte, niet dynamisch via de oculus.
- tekst was te dichtbij of te groot
- tekst is wat te lang en moet even opgesplitst worden
- test het zonder de tekst 
- tekst is te ingewikkeld 
- knop was per ongeluk ingedrukt
- neem wat tijd an het einde om mensen te laten rond kijken
- tijdens eind scene de grond verdord
- dooie planten bij foute keuze 
- met planten misschien niet leeg beginnen
- werken met warm en koud licht 
- ice spikes aan de venster bank bijvoorbeeld
- omgevallen/dooie bomen in bad ending
- in de keuken misschien een vogel die chirpt als je goeie keuze maakt en als je slechte keuze maakt dat hij dood omvalt 
- infocoach.nl link in de eind scene
- prijs van de regenval douche voelt niet correct (te goedkoop)
- laat de robot meer in rond lopen om mensen aan te sporen hem te volgen zodat ze rond kijken
- laat de robot van deur tot deur lopen om het gevoel te geven dat je door een echt appartement heen gaat.
- eind scene geeft instructie om de headset af te doen en terug te geven
- taal keuze wordt door coach gemaakt door 1 van de knoppen in te drukken
- haptic feedback op button press
- kraan dopje zichtbaar maken 
- 1 controller voor de speler en de ander voor de coach waar taal en reset control op zit
- Keuken raam ventilator rooster plaatsen boven in het raam https://www.sloterop.nl/ducoton-10-ventilatierooster-glasaftrek-80mm/

### Specific questioned feedback
- Hoe voelde de game om te spelen?(Performance vraag) //
- Hoe voelde de lengte en snelheid van de game?
voelt wel goed zeker als er nog een extra opdracht bij komt. 
- Hoe vonden jullie dat het eruit zag zijn er ideeen voor verbeteringen?
- Wat wat jullie indruk van de virtual assistent?
- Hoe voelde de controls? Zijn deze simpel genoeg?
- Denken jullie dat jullie hiermee kunnen werken?


### Ideeen op de backlog feedback
- Data opslag? Denken jullie dat er toegevoegde waarde is aan mensen hun keuzes bijhouden en opslaan? - niet 
- Hand tracking? Denken jullie dat het het waard is om te kijken dat we hand tracking implementeren of is de huidige manier goed genoeg? 
- Deelnemer resetten? We gebruiken nu een knoppen combinatie maar wat vinden jullie hiervan en hebben jullie misschien nog suggesties voor het gebruik? //
- Selectie maken? Op dit moment wordt er een keuze gemaakt zodra je de knop aanraakt maar moet daar misschien een delay komen dat je een knop voor 2 seconden bijvoorbeeld aanraakt en dat dan pas je keuze geregistreerd wordt? Nope 

### Nog vragen of feedback?
- ll