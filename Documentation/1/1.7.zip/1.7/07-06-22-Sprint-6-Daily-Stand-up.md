Nick is vermist, we hebben met z'n twee gezeten en besproken wat we gaan doen vandaag. Sheru zal focussen op het afmaken van de douche game en ik ga kijken om de reset functionaliteit te implementeren.

### Goals of the day
- Julian: Reset functionaliteit voor de gebruiker
- Sheru: Scripting voor de douche game af zodat de game speelbaar is en naar het einde gaat.