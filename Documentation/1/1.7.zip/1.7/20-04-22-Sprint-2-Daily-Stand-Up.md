We hebben besproken wat er afgelopen sprint is gebouwd en wat er voor de nieuwe sprint is afgesproken met de klant. We hebben Nick en Pelle ook een demo gegeven in de huidige versie en gekeken waar hun nu met KD: Game Development zijn. Hun zullen hier deze week zeker nog wel mee bezig zijn.

### Goals
- Julian: Bouw knoppen waar je op kan drukken in VR.
- Sheru: Bouw een assistent 0.1 versie (een tekst bubbel die je kan aanpassen).
- Nick: Afmaken "I Like to Move It!".
- Pelle: Afmaken "Soccer Scripting".