Nick is ziek, we hebben dus in de trein de stand-up al gehouden. Sheru kwam er niet uit met de reset knop dus Julian gaat hier nu naar kijken. Sheru gaat voor nu de nieuwe VR assistent implementeren. 

### Goals of the day:
Julian: Reset Knop af en werkend
Sheru: Nieuwe virtual assistent implementeren en animeren vanaf tutorial tot level 2 (living room)