Wat ging goed?

* Samenwerking
* Blije klant

Wat kon beter gaan?

* Te veel gewerkt in main branch voor gemak
* Board bijhouden
* User Stories

Ideas?

* $Ideas = NULL;

Praise

* Sheru

Afspraken:

* Verwijder oude branches
* Niet meer werken in main, alleen nog mergen naar main.