We hebben het vrij kort gehouden voor vandaag omdat iedereen al wist wat ze zouden gaan doen vandaag. We hadden ook de dag hiervoor een document van Hans ontvangen met wensen, deze moeten we dus even doornemen en kijken wat we hiervan al hebben en wat we hiervan nu voor deze sprint willen doen.

### Goals
- Nick: Quest for water - Hij is ervoor aan het zorgen dat de kraan water particles en sound effects heeft.
- Sheru: Quest for grass - Hij is een omgeving gaan maken voor buiten die je door het raam heen kan zien zodat die later weer op basis van keuzes verandert. 
- Julian: Quest for hands - De VR hands worden niet helemaal juist getracked wanneer je je handen draait. Deze is voor hem om op te lossen.